import { Tabs } from "expo-router";
import { TabBar } from "../../components/nav/TabBar";

export default function AppLayout() {
  return (
    <Tabs tabBar={() => <TabBar />} screenOptions={{ headerShown: false }}>
      <Tabs.Screen name="(feed)" />
      <Tabs.Screen name="reels" />
      <Tabs.Screen name="messenger" />
      <Tabs.Screen name="activity" />
      {/* These are navigable but not in the pill — TabBar handles them directly */}
      <Tabs.Screen name="search" options={{ href: null }} />
      <Tabs.Screen name="create" options={{ href: null }} />
      <Tabs.Screen name="profile" options={{ href: null }} />
    </Tabs>
  );
}
