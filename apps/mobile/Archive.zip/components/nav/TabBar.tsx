import {
  Home02Icon,
  Notification01Icon,
  Search01Icon,
  SendIcon,
  VideoReplayIcon,
} from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react-native";
import { useRouter, useSegments } from "expo-router";
import { Pressable, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const PILL_TABS: {
  segment: string;
  icon: any;
}[] = [
  { segment: "(feed)", icon: Home02Icon },
  { segment: "reels", icon: VideoReplayIcon },
  { segment: "messenger", icon: SendIcon },
  { segment: "activity", icon: Notification01Icon },
];

const CREAM = "rgba(255,255,255,0.85)";
const DARK = "#1A1A1A";
const MUTED = "#8A8278";
const ACCENT = "#E46D41";
const BORDER = "rgba(255,255,255,0.6)";

const shadow = {
  shadowColor: "#000",
  shadowOffset: { width: 0, height: 8 },
  shadowOpacity: 0.14,
  shadowRadius: 16,
  elevation: 10,
};

const PILL_H = 58;

export function TabBar() {
  const router = useRouter();
  const segments = useSegments();
  const insets = useSafeAreaInsets();

  const currentSegment =
    [...segments].reverse().find((s) => !s.startsWith("(")) ?? "";

  function isActive(segment: string) {
    if (segment === "(feed)")
      return currentSegment === "" || segments.includes("(feed)");
    return currentSegment === segment;
  }

  function navigate(segment: string) {
    if (segment === "(feed)") router.push("/(app)/(feed)");
    else router.push(`/(app)/${segment}` as any);
  }

  return (
    <View
      style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        paddingBottom: insets.bottom + 12,
        paddingHorizontal: 22,
        flexDirection: "row",
        alignItems: "center",
        gap: 10,
      }}
      pointerEvents="box-none"
    >
      {/* Пилюля */}
      <View
        style={{
          flex: 1,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-evenly",
          height: PILL_H,
          borderRadius: PILL_H / 2,
          backgroundColor: CREAM,
          borderWidth: 1,
          borderColor: BORDER,
          ...shadow,
        }}
      >
        {PILL_TABS.map((tab) => {
          const active = isActive(tab.segment);
          return (
            <Pressable
              key={tab.segment}
              onPress={() => navigate(tab.segment)}
              style={({ pressed }) => ({
                width: 48,
                height: PILL_H - 10,
                alignItems: "center",
                justifyContent: "center",
                borderRadius: (PILL_H - 10) / 2,
                // Активный фон теперь с фирменным цветом
                backgroundColor: active ? "#FFF5F0" : "transparent",
                opacity: pressed ? 0.6 : 1,
                ...(active && {
                  shadowColor: ACCENT,
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.15,
                  shadowRadius: 4,
                  elevation: 2,
                }),
              })}
            >
              {/* Иконка: активная - оранжевая, неактивная - серая */}
              <HugeiconsIcon
                icon={tab.icon}
                size={22}
                color={active ? ACCENT : MUTED}
                strokeWidth={active ? 2.2 : 1.8}
              />
            </Pressable>
          );
        })}
      </View>

      {/* Поиск */}
      <View
        style={{
          width: PILL_H,
          height: PILL_H,
          borderRadius: PILL_H / 2,
          backgroundColor: CREAM,
          borderWidth: 1,
          borderColor: BORDER,
          ...shadow,
          overflow: "hidden",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Pressable
          onPress={() => router.push("/(app)/search")}
          style={({ pressed }) => ({
            width: PILL_H,
            height: PILL_H,
            alignItems: "center",
            justifyContent: "center",
            opacity: pressed ? 0.6 : 1,
            backgroundColor: isActive("search") ? "#FFF5F0" : "transparent",
          })}
        >
          <HugeiconsIcon
            icon={Search01Icon}
            size={22}
            color={isActive("search") ? ACCENT : MUTED}
            strokeWidth={2}
          />
        </Pressable>
      </View>
    </View>
  );
}
